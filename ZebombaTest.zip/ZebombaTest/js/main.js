import { data } from './data';

console.log(data.ratings);

const button = document.getElementById('btn');
const woman = document.getElementById('woman');
counter = 0;
reset = -1;

const rating = document.getElementById('rating');
const popup = document.getElementById('popup');

const close_popup = document.getElementById('close_popup');

button.onclick = function() {
  counter++, counter < 10
  reset++
  woman.classList.toggle('move_' + counter);
  woman.classList.remove('move_' + reset);
  woman.classList.remove('move_10');
  if (counter == 10){
    counter = 0
    reset = -1
  }
};

rating.onclick = function() {
  popup.style.top = '95px';
  popup.style.transition = '2s';
};
close_popup.onclick = function() {
  popup.style.top = '-470px';
};