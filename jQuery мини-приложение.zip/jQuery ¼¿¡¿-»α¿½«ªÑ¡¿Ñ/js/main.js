$(document).ready(function () {
  $('.small a').click(function(e){
    $('.big img').hide().attr('src', $(this).attr('href')).fadeIn(1000);
    e.preventDefault();
  });

  $('.button').click(function() {
    $('.gallery').slideToggle(500);
    if($('.button').text()=='-'){
      $('.button').text('+')
    } else {
      $('.button').text('-')
    }
  })

  $('.small a img').click(function() {
    $('.small a img').fadeTo(500, 1).css({
      'border': 'none'
    });
    $(this).fadeTo(500, 0.6).css({
      'border': '1px dotted red' 
    });
  });


  $('.button').click(function() {
      $('p').text();
      if($('.button').text()=='-'){
        $('p').text('Нажми на минус')
      } else {
        $('p').text('Нажми на плюс')
      }
  });
});