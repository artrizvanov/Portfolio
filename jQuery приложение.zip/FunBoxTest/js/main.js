$(document).ready(function() {
const cat = $('.cat');
const cat3 = $('.cat-3');

// START СОБЫТИЕ ПРИ КЛИКЕ НА БЛОК
cat.on( "click", function() {
  $(this).toggleClass( "cat-click" );
});
// END СОБЫТИЕ ПРИ КЛИКЕ НА БЛОК

// START СОБЫТИЕ DISABLED ПРИ КЛИКЕ НА БЛОК
cat3.on( "click", function() {
  if($(this).toggleClass( "disabled" )){
    $(this).addClass('disabled');
  };
});
// END СОБЫТИЕ DISABLED ПРИ КЛИКЕ НА БЛОК

// START СОБЫТИЕ SELECTHOVER НА БЛОК
cat.hover(function(){
  if ($(this).hasClass('cat-click')){
    $(this).toggleClass('cat-click-hover')
  };
});
});
// START СОБЫТИЕ SELECTHOVER НА БЛОК